# authenticated_IRC
A kind of IRC client to work on local network
